'''
For / Else em Python
https://www.youtube.com/watch?v=Q2hx-cbYdj4&list=PLbIBj8vQhvm0ayQsrhEf-7-8JAj-MwmPr&index=14
'''

# Essa aula caso precise assistir a aula.