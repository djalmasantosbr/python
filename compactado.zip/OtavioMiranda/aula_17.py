'''
Função lambda
'''
def funcao(arg, arg2):
    return arg * arg2

var = funcao(2,2)
print(var)

# em formato labda

a = lambda x, y: x * y

print(a(2,2))

# Exemplo pratico

# https://www.youtube.com/watch?v=EQRsJ2bKvUU&list=PLbIBj8vQhvm0ayQsrhEf-7-8JAj-MwmPr&index=22

