# compreensão de lista
# Só acompanhei a aula