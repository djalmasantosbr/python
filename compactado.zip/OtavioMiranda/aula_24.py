# compreensão em dicionários

#Só vou acompanhar a aula

