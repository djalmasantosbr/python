#Try, Except - Tratando Exceções em Python

# Vou voltar a estudar em outra oportunidade

# https://www.youtube.com/watch?v=RHSxIKGCX7c&list=PLbIBj8vQhvm0ayQsrhEf-7-8JAj-MwmPr&index=31
