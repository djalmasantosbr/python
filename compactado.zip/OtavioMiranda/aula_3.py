# Entrada de dados

nome = input('Qual o seu nome? ')
idade = int(input('Qual a sua idade? '))
ano_nascimento = 2023 - idade

print("")
print(f'{nome} tem {idade}.Nasceu em {ano_nascimento}.')


numero_1 = input('digite um número: ')
numero_2 = input('Digite outro número:')
print('A soma é: {}'.format(int(numero_1) + int(numero_2)))
