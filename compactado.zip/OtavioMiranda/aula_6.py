# Indices
#Positivos  [012345678]
texto =     'python_s2'
#Negativos -[987654321]

url = 'www.google.com.br/'

print(url[:-1])

nova_string = texto[2:6]
print(nova_string)

nova_string = texto[-1]
print(nova_string)

nova_string = texto[-9]
print(nova_string)

nova_string = texto[-9:-3]
print(nova_string)

nova_string = texto[:-1]
print(nova_string)

nova_string = texto[:-2]
print(nova_string)

nova_string = texto[0:6:2]
print(nova_string)

nova_string = texto[0::3]
print(nova_string)

print(len(texto))

